// Quick Sticky Notes popup.
// Notes live in chrome.storage.local under one key, "notes":
//   { "example.com": { text: "...", updated: 1763800000000 }, "__general__": { ... } }
// Note text is only put on the page with textContent / .value, never innerHTML,
// so a note can never run as code.

const GENERAL = "__general__"; // storage key of the General note
const MAX_LENGTH = 200; // characters per note
const SAVE_DELAY_MS = 300; // wait this long after the last key press before saving

const $ = (id) => document.getElementById(id);

let notes = {}; // every saved note
let siteKey = null; // hostname of the current tab, or null on a browser page
let activeKey = null; // which note the editor is showing (null = editor is disabled)
let dirty = false; // true while there is typed text that is not saved yet
let saveTimer = null;

// ---------- Helpers ----------

/** "https://www.example.com/a" -> "example.com". Returns null for edge://, a new tab, files, etc. */
function siteKeyFromUrl(url) {
  try {
    const u = new URL(url);
    if (u.protocol !== "http:" && u.protocol !== "https:") return null;
    return u.hostname.replace(/^www\./, "") || null;
  } catch {
    return null;
  }
}

function setStatus(text) {
  $("status").textContent = text;
}

function updateCounter() {
  const length = $("text").value.length;
  $("chars").textContent = `${length} / ${MAX_LENGTH}`;
  $("chars").classList.toggle("near", length >= MAX_LENGTH - 20); // turns red near the limit
}

function highlightTab(which) {
  $("tab-site").setAttribute("aria-selected", String(which === "site"));
  $("tab-general").setAttribute("aria-selected", String(which === "general"));
}

// ---------- Storage ----------

async function loadNotes() {
  const { notes: saved } = await chrome.storage.local.get("notes");
  notes = saved && typeof saved === "object" ? saved : {};
}

/** Save the editor text now. An empty note is removed instead of being stored. */
async function commit() {
  clearTimeout(saveTimer);
  if (!dirty || !activeKey) return;
  dirty = false;
  const text = $("text").value;
  if (text.trim() === "") delete notes[activeKey];
  else notes[activeKey] = { text, updated: Date.now() };
  await chrome.storage.local.set({ notes });
  setStatus("Saved");
}

// ---------- Views ----------

/** Show one note in the editor. */
async function openNote(key) {
  await commit(); // never lose what was typed in the other note
  activeKey = key;

  const where = $("where");
  where.replaceChildren();
  if (key === GENERAL) {
    where.textContent = "General note (not tied to a website)";
  } else {
    const name = document.createElement("strong");
    name.textContent = key;
    where.append("Note for ", name);
  }

  $("text").disabled = false;
  $("text").value = notes[key]?.text || "";
  highlightTab(key === GENERAL ? "general" : "site");
  updateCounter();
  setStatus("Saved");
  $("text").focus();
}

/** The "This site" tab on a browser page: the editor is switched off and we say why. */
async function showSiteUnavailable() {
  await commit();
  activeKey = null;
  $("where").textContent = "Browser pages can't have a site note. Use the General tab instead.";
  $("text").value = "";
  $("text").disabled = true;
  highlightTab("site");
  updateCounter();
  setStatus("");
}

const showSite = () => (siteKey ? openNote(siteKey) : showSiteUnavailable());

// ---------- Events ----------

$("text").addEventListener("input", () => {
  if (!activeKey) return;
  dirty = true;
  setStatus("Saving...");
  updateCounter();
  clearTimeout(saveTimer);
  saveTimer = setTimeout(commit, SAVE_DELAY_MS);
});

$("tab-site").addEventListener("click", showSite);
$("tab-general").addEventListener("click", () => openNote(GENERAL));

// Closing the popup must not lose the last few key presses.
window.addEventListener("pagehide", commit);
document.addEventListener("visibilitychange", () => document.hidden && commit());

// ---------- Start ----------

(async function init() {
  await loadNotes();
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  siteKey = tab?.url ? siteKeyFromUrl(tab.url) : null;
  await showSite();
})();
