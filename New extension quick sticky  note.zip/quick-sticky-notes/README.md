# Quick Sticky Notes

A sticky note in your browser toolbar: one short note for every website, plus a General note.
Plain HTML, CSS and JavaScript. No setup, no accounts, no network requests.

## Install (2 minutes)
1. Unzip, so you have a folder named `quick-sticky-notes` that contains `manifest.json`.
2. Open `edge://extensions` (or `chrome://extensions`) and turn on **Developer mode**.
3. Click **Load unpacked** and choose the `quick-sticky-notes` folder (the one with `manifest.json`).
4. Pin **Quick Sticky Notes** with the puzzle-piece icon. Shortcut: **Alt+Shift+N**.

## How to use
- **This site** shows the note for the website in your current tab. `www.example.com` and `example.com` share one note.
- **General** is a note that is not tied to any website.
- Notes **save automatically** about a quarter of a second after you stop typing. The top right says "Saving..." and then "Saved".
- Each note can hold **200 characters**. The counter turns red when you are close to the limit.
- Delete all the text in a note and it is removed from storage.
- On browser pages (new tab, `edge://...`), "This site" is switched off and tells you why. Use **General** there.

## Test checklist
- [ ] Open any website, type a note, close the popup, reopen it: the note is still there.
- [ ] Open another page of the same website: the same note. A different website: an empty note.
- [ ] Click General, type something, click This site, click General again: both notes are still right.
- [ ] Type or paste more than 200 characters: it stops at 200 and the counter turns red.
- [ ] Type `<b>hi</b>`: it shows as plain text, not bold.
- [ ] Open a new tab page: "This site" is greyed out with a one-line explanation, and General still works.
- [ ] Press Alt+Shift+N: the popup opens. (If another extension uses this shortcut, set a new one at `edge://extensions/shortcuts`.)

## Files
| File | What it does |
|---|---|
| manifest.json | Extension definition (Manifest V3, permissions: storage and activeTab only) |
| popup.html / popup.css / popup.js | The popup you see and its logic |
| icons/ | Toolbar icons (16, 32, 48 and 128 px) |

Notes are stored only in this browser (`chrome.storage.local`, key `notes`). Removing the extension deletes them.
