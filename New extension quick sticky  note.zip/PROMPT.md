# Quick Sticky Notes: ICEPOT prompt

## I: Instruction
Build a complete Chrome / Edge extension called **Quick Sticky Notes**, a notepad that lives in the toolbar popup. Features:
- One note per website. When the popup opens, it shows the note for the site in the current tab
- A General note that is not tied to any site.
- Auto-save while typing (about 300 ms after the last key press), with a small "Saving..." / "Saved" indicator. Save again when the popup closes so nothing is lost.
- A character counter with a limit of 200 characters per note.
- An empty note is removed from storage instead of being saved.
- On pages that cannot have a site note (browser pages such as `edge://` or a new tab) disable the "This site" editor, explain why in one line, and let the user use the General note.
- Keyboard shortcut `Alt+Shift+N` opens the popup.

## C: Context
- Tech stack: HTML, CSS and plain JavaScript
- Platform: Manifest V3 for Google Chrome and Microsoft Edge.
- Permissions allowed: `storage` and `activeTab` only. Read the current tab's address with `chrome.tabs.query` (allowed by `activeTab` when the popup is opened).
- Files: `manifest.json`, `popup.html`, `popup.css`, `popup.js`, `icons/` (16, 32, 48, 128 px PNG), `README.md`. No background script is needed.
- Store notes in `chrome.storage.local` under one key, `notes`, as an object: `{ "<hostname or __general__>": { text, updated } }`.
- Never use `innerHTML` with note text. Always use `textContent`, so a note can never run as code.
- Style: yellow sticky-note look (accent `#F5B400`, dark text `#2B2300`), rounded corners, system font, supports the user's light or dark theme.
- The user is a beginner who will load the folder with "Load unpacked", so it must work with no setup.

## E: Example
```js
// storage shape
{ notes: {
    "example.com": { text: "Check pricing page", updated: 1763800000000 },
    "__general__": { text: "Buy milk", updated: 1763800500000 }
} }

// auto-save pattern
textarea.addEventListener("input", () => {
  dirty = true;
  status("Saving...");
  clearTimeout(timer);
  timer = setTimeout(commit, 300);
});
```

## P: Persona
You are a browser-extension engineer who writes simple, safe, well-commented code for beginners and cares about not losing the user's data.

## O: Output format
1. A file tree.
2. Each file in its own fenced code block with its path as a heading.
3. A README with install steps ("Load unpacked") and a manual test checklist.
4. Nothing else between the files.

## T: Tone
Friendly and practical. Short plain-English comments. No jargon in the README.
